+++
# About/Biography widget.
widget = "about"  # Do not modify this line!
active = true  # Activate this widget? true/false
weight = 5  # Order that this section will appear in.

title = "Biography"

# Choose the user profile to display
# This should be the username of a profile in your `content/author/` folder.
author = "Admin"
+++
