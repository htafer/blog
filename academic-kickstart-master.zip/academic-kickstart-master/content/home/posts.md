+++
# Recent Posts widget.
# This widget displays recent posts from `content/post/`.
widget = "posts"  # Do not modify this line!
active = true  # Activate this widget? true/false
weight = 40  # Order that this section will appear.

title = "Recent Posts"
subtitle = ""

# Number of recent posts to list.
count = 5

# View.
#   1 = List
#   2 = Compact
#   3 = Card
view = 2

# Filter posts by tag or category.
#  E.g. to only show posts tagged with `Academic`, set `filter_tag = "Academic"`
filter_tag = ""
filter_category = ""
+++

