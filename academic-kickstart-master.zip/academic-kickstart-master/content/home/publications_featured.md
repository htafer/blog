+++
# Featured Publications widget.
# This widget displays publications from `content/publication/` which have
# `featured = true` in their front matter.
widget = "publications_featured"  # Do not modify this line!
active = true  # Activate this widget? true/false

title = "Featured Publications"
subtitle = ""

# Order that this section will appear in.
weight = 10

# View.
#   1 = List
#   2 = Compact
#   3 = Card
#   4 = Citation
view = 3

# Filter by publication type.
# -1: Any
#  0: Uncategorized
#  1: Conference proceedings
#  2: Journal
#  3: Work in progress
#  4: Technical report
#  5: Book
#  6: Book chapter
publication_type = "-1"
+++

