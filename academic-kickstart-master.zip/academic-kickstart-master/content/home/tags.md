+++
# Tag Cloud widget.
widget = "tag_cloud"  # Do not modify this line!
active = true  # Activate this widget? true/false

title = "Tags"
subtitle = ""

# Order that this section will appear in.
weight = 65

+++
