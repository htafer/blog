+++
# Recent and Upcoming Talks widget.
widget = "talks"  # Do not modify this line!
active = true  # Activate this widget? true/false

title = "Recent & Upcoming Talks"
subtitle = ""

# Order that this section will appear in.
weight = 30

# Number of talks to list.
count = 10

# View.
#   1 = List
#   2 = Compact
#   3 = Card
view = 2

# Exclude talks that are shown in the Featured Talks widget?
exclude_featured = false
+++

