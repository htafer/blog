+++
# People widget.
widget = "people"  # Do not modify this line!
active = false  # Activate this widget? true/false

title = "People"
subtitle = ""

# Order that this section will appear in.
weight = 68

# List user groups to display.
#   Edit each user's `user_groups` to add them to one or more of these groups.
user_groups = ["Principal Investigators",
               "Researchers",
               "Grad Students",
               "Administration",
               "Visitors",
               "Alumni"]
+++
