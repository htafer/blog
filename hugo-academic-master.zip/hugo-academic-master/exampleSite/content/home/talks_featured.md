+++
# Featured Talks widget.
widget = "talks_featured"  # Do not modify this line!
active = false  # Activate this widget? true/false

title = "Featured Talks"
subtitle = ""

# Order that this section will appear in.
weight = 29

# View.
#   1 = List
#   2 = Compact
#   3 = Card
view = 3
+++
